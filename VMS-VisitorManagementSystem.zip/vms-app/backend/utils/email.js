const nodemailer = require('nodemailer');
const QRCode = require('qrcode');
require('dotenv').config();

function createTransporter() {
  return nodemailer.createTransport({
    host: process.env.SMTP_HOST || 'smtp.gmail.com',
    port: parseInt(process.env.SMTP_PORT) || 587,
    secure: process.env.SMTP_SECURE === 'true',
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
    },
  });
}

async function generateQRCode(data) {
  try {
    return await QRCode.toDataURL(JSON.stringify(data), {
      width: 200,
      margin: 2,
      color: { dark: '#1a56db', light: '#ffffff' },
    });
  } catch (err) {
    console.error('QR Code generation error:', err);
    return null;
  }
}

function getInitials(name) {
  return name.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();
}

function formatTime(dateStr) {
  return new Date(dateStr).toLocaleString('en-IN', {
    day: '2-digit', month: 'short', year: 'numeric',
    hour: '2-digit', minute: '2-digit', hour12: true
  });
}

function generateDigitalIDCard(visitor, qrCodeDataUrl) {
  const initials = getInitials(visitor.name);
  const companyName = process.env.COMPANY_NAME || 'Your Company';

  return `
  <div style="font-family: 'Segoe UI', Arial, sans-serif; max-width: 380px; margin: 0 auto;">
    <div style="background: linear-gradient(135deg, #1a56db 0%, #1d4ed8 100%); border-radius: 16px; padding: 24px; color: #ffffff; position: relative; overflow: hidden;">
      <div style="position: absolute; top: -20px; right: -20px; width: 120px; height: 120px; background: rgba(255,255,255,0.06); border-radius: 50%;"></div>
      <div style="position: absolute; bottom: -30px; left: -20px; width: 100px; height: 100px; background: rgba(255,255,255,0.04); border-radius: 50%;"></div>

      <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 20px;">
        <div>
          <div style="font-size: 10px; text-transform: uppercase; letter-spacing: 1.5px; opacity: 0.7; margin-bottom: 4px;">VISITOR PASS</div>
          <div style="font-size: 15px; font-weight: 700;">${companyName}</div>
        </div>
        <div style="background: rgba(255,255,255,0.15); border: 2px solid rgba(255,255,255,0.3); border-radius: 50%; width: 52px; height: 52px; display: flex; align-items: center; justify-content: center; font-size: 18px; font-weight: 700;">
          ${initials}
        </div>
      </div>

      <div style="margin-bottom: 16px;">
        <div style="font-size: 22px; font-weight: 700; margin-bottom: 4px;">${visitor.name}</div>
        <div style="font-size: 12px; opacity: 0.8; margin-bottom: 2px;">📞 ${visitor.phone}</div>
        ${visitor.company ? `<div style="font-size: 12px; opacity: 0.8; margin-bottom: 2px;">🏢 ${visitor.company}</div>` : ''}
        <div style="font-size: 12px; opacity: 0.8;">🤝 Meeting: ${visitor.person_to_meet_name}</div>
      </div>

      <div style="border-top: 1px solid rgba(255,255,255,0.2); padding-top: 14px; display: flex; justify-content: space-between; align-items: center;">
        <div>
          <div style="font-size: 9px; opacity: 0.6; text-transform: uppercase; letter-spacing: 0.5px;">VISITOR ID</div>
          <div style="font-size: 14px; font-weight: 700;">${visitor.visitor_id}</div>
          <div style="font-size: 10px; opacity: 0.7; margin-top: 2px;">⏰ ${formatTime(visitor.checkin_time)}</div>
        </div>
        <div style="text-align: center;">
          <div style="background: rgba(255,255,255,0.2); padding: 4px 10px; border-radius: 20px; font-size: 10px; font-weight: 600; margin-bottom: 4px;">${visitor.visitor_type_name}</div>
          ${qrCodeDataUrl ? `<img src="${qrCodeDataUrl}" alt="QR Code" style="width: 60px; height: 60px; border-radius: 6px; background: white; padding: 2px;" />` : ''}
        </div>
      </div>
    </div>
    <div style="text-align: center; margin-top: 10px; font-size: 10px; color: #6b7280;">
      Show this pass for verification • Valid for today's visit only
    </div>
  </div>`;
}

async function sendVisitorCheckinEmail(visitor) {
  if (!process.env.SMTP_USER || !visitor.email) return { success: false, reason: 'No email configured' };

  try {
    const transporter = createTransporter();
    const companyName = process.env.COMPANY_NAME || 'Your Company';

    const qrData = {
      visitorId: visitor.visitor_id,
      name: visitor.name,
      checkinTime: visitor.checkin_time,
      personToMeet: visitor.person_to_meet_name,
    };
    const qrCodeDataUrl = await generateQRCode(qrData);
    const idCardHtml = generateDigitalIDCard(visitor, qrCodeDataUrl);

    const html = `
    <!DOCTYPE html>
    <html>
    <head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"></head>
    <body style="margin:0;padding:0;background:#f8fafc;font-family:'Segoe UI',Arial,sans-serif;">
      <div style="max-width:600px;margin:0 auto;padding:20px;">

        <div style="background:#1a56db;border-radius:12px 12px 0 0;padding:24px;text-align:center;">
          <div style="font-size:32px;margin-bottom:8px;">✅</div>
          <h1 style="color:#fff;margin:0;font-size:20px;font-weight:700;">Check-In Confirmed!</h1>
          <p style="color:rgba(255,255,255,0.8);margin:8px 0 0;font-size:13px;">You have been successfully checked in</p>
        </div>

        <div style="background:#fff;padding:24px;border-left:1px solid #e2e8f0;border-right:1px solid #e2e8f0;">
          <p style="font-size:14px;color:#374151;line-height:1.6;">Hello <strong>${visitor.name}</strong>,</p>
          <p style="font-size:14px;color:#374151;line-height:1.6;">
            You have been successfully checked in at <strong>${companyName}</strong>.
            Please find your digital visitor pass below — show it if asked for verification.
          </p>

          <div style="background:#f0fdf4;border-radius:10px;padding:16px;margin:16px 0;border-left:4px solid #059669;">
            <div style="font-size:12px;font-weight:600;color:#065f46;margin-bottom:8px;">✅ VISIT DETAILS</div>
            <table style="width:100%;font-size:13px;color:#374151;">
              <tr><td style="padding:3px 0;color:#6b7280;width:120px;">Visitor ID:</td><td><strong>${visitor.visitor_id}</strong></td></tr>
              <tr><td style="padding:3px 0;color:#6b7280;">Check-in Time:</td><td>${formatTime(visitor.checkin_time)}</td></tr>
              <tr><td style="padding:3px 0;color:#6b7280;">Person to Meet:</td><td><strong>${visitor.person_to_meet_name}</strong></td></tr>
              <tr><td style="padding:3px 0;color:#6b7280;">Department:</td><td>${visitor.person_dept || '—'}</td></tr>
              <tr><td style="padding:3px 0;color:#6b7280;">Visit Type:</td><td>${visitor.visitor_type_name}</td></tr>
            </table>
          </div>

          <div style="margin:20px 0;">
            <div style="font-size:13px;font-weight:600;color:#374151;margin-bottom:12px;">Your Digital Visitor Pass:</div>
            ${idCardHtml}
          </div>

          <div style="background:#fff8ec;border-radius:10px;padding:14px;border-left:4px solid #d97706;margin-top:16px;">
            <div style="font-size:12px;font-weight:600;color:#92400e;margin-bottom:4px;">⚠️ IMPORTANT REMINDER</div>
            <p style="font-size:12px;color:#92400e;margin:0;line-height:1.5;">
              Please remember to <strong>check out at the reception</strong> before leaving the premises.
              Checkout is mandatory for all visitors.
            </p>
          </div>
        </div>

        <div style="background:#f8fafc;border-radius:0 0 12px 12px;padding:16px;text-align:center;border:1px solid #e2e8f0;border-top:none;">
          <p style="font-size:11px;color:#9ca3af;margin:0;">
            This is an automated message from ${companyName} Visitor Management System.<br>
            Please do not reply to this email.
          </p>
        </div>
      </div>
    </body>
    </html>`;

    await transporter.sendMail({
      from: `"${process.env.EMAIL_FROM_NAME || companyName}" <${process.env.EMAIL_FROM || process.env.SMTP_USER}>`,
      to: visitor.email,
      subject: `✅ Check-in Confirmed | ${companyName} | ${visitor.visitor_id}`,
      html,
    });

    return { success: true };
  } catch (err) {
    console.error('Visitor email error:', err);
    return { success: false, error: err.message };
  }
}

async function sendHostNotificationEmail(visitor) {
  if (!process.env.SMTP_USER || !visitor.person_to_meet_email) return { success: false, reason: 'No email configured' };

  try {
    const transporter = createTransporter();
    const companyName = process.env.COMPANY_NAME || 'Your Company';

    const html = `
    <!DOCTYPE html>
    <html>
    <head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"></head>
    <body style="margin:0;padding:0;background:#f8fafc;font-family:'Segoe UI',Arial,sans-serif;">
      <div style="max-width:600px;margin:0 auto;padding:20px;">

        <div style="background:#7c3aed;border-radius:12px 12px 0 0;padding:24px;text-align:center;">
          <div style="font-size:32px;margin-bottom:8px;">🔔</div>
          <h1 style="color:#fff;margin:0;font-size:20px;font-weight:700;">Visitor Arrived!</h1>
          <p style="color:rgba(255,255,255,0.8);margin:8px 0 0;font-size:13px;">Someone is waiting to meet you at the reception</p>
        </div>

        <div style="background:#fff;padding:24px;border:1px solid #e2e8f0;border-top:none;">
          <p style="font-size:14px;color:#374151;line-height:1.6;">Hello <strong>${visitor.person_to_meet_name}</strong>,</p>
          <p style="font-size:14px;color:#374151;line-height:1.6;">
            A visitor has arrived at the <strong>${companyName}</strong> reception to meet you.
          </p>

          <div style="background:#f5f3ff;border-radius:12px;padding:20px;margin:16px 0;border:1px solid #ddd6fe;">
            <div style="display:flex;align-items:center;margin-bottom:14px;">
              <div style="width:48px;height:48px;background:#7c3aed;border-radius:50%;display:flex;align-items:center;justify-content:center;color:white;font-weight:700;font-size:16px;margin-right:12px;flex-shrink:0;">
                ${getInitials(visitor.name)}
              </div>
              <div>
                <div style="font-size:16px;font-weight:700;color:#1f2937;">${visitor.name}</div>
                <div style="font-size:12px;color:#6b7280;">${visitor.visitor_type_name}</div>
              </div>
            </div>
            <table style="width:100%;font-size:13px;color:#374151;">
              <tr><td style="padding:4px 0;color:#6b7280;width:120px;">From:</td><td><strong>${visitor.company || 'Not specified'}</strong></td></tr>
              <tr><td style="padding:4px 0;color:#6b7280;">Phone:</td><td>${visitor.phone}</td></tr>
              <tr><td style="padding:4px 0;color:#6b7280;">Checked In:</td><td>${formatTime(visitor.checkin_time)}</td></tr>
              <tr><td style="padding:4px 0;color:#6b7280;">Purpose:</td><td>${visitor.purpose || 'Not specified'}</td></tr>
              <tr><td style="padding:4px 0;color:#6b7280;">Visitor ID:</td><td><strong>${visitor.visitor_id}</strong></td></tr>
            </table>
          </div>

          <div style="background:#f0fdf4;border-radius:10px;padding:14px;border-left:4px solid #059669;">
            <p style="font-size:13px;color:#065f46;margin:0;line-height:1.5;">
              📍 <strong>Your visitor is waiting at the reception area.</strong><br>
              Please come down or send someone to escort them.
            </p>
          </div>
        </div>

        <div style="background:#f8fafc;border-radius:0 0 12px 12px;padding:16px;text-align:center;border:1px solid #e2e8f0;border-top:none;">
          <p style="font-size:11px;color:#9ca3af;margin:0;">
            ${companyName} Visitor Management System • Automated Notification
          </p>
        </div>
      </div>
    </body>
    </html>`;

    await transporter.sendMail({
      from: `"${process.env.EMAIL_FROM_NAME || companyName}" <${process.env.EMAIL_FROM || process.env.SMTP_USER}>`,
      to: visitor.person_to_meet_email,
      subject: `🔔 Visitor Waiting: ${visitor.name} | ${companyName} Reception`,
      html,
    });

    return { success: true };
  } catch (err) {
    console.error('Host email error:', err);
    return { success: false, error: err.message };
  }
}

async function sendCheckoutReminderEmail(visitor) {
  if (!process.env.SMTP_USER) return { success: false };
  // Send to host that visitor hasn't checked out
  const transporter = createTransporter();
  const companyName = process.env.COMPANY_NAME || 'Your Company';

  try {
    const html = `
    <!DOCTYPE html><html><body style="font-family:'Segoe UI',Arial,sans-serif;background:#f8fafc;margin:0;padding:20px;">
      <div style="max-width:500px;margin:0 auto;background:#fff;border-radius:12px;overflow:hidden;border:1px solid #e2e8f0;">
        <div style="background:#d97706;padding:20px;text-align:center;">
          <div style="font-size:28px;margin-bottom:6px;">⚠️</div>
          <h2 style="color:#fff;margin:0;font-size:18px;">Checkout Reminder</h2>
        </div>
        <div style="padding:20px;">
          <p style="font-size:14px;color:#374151;">Visitor <strong>${visitor.name}</strong> (${visitor.visitor_id}) checked in at
          ${formatTime(visitor.checkin_time)} and has not checked out yet.</p>
          <p style="font-size:13px;color:#6b7280;">Please ensure they check out at the reception before leaving.</p>
        </div>
      </div>
    </body></html>`;

    await transporter.sendMail({
      from: `"${companyName} VMS" <${process.env.EMAIL_FROM || process.env.SMTP_USER}>`,
      to: visitor.person_to_meet_email,
      subject: `⚠️ Checkout Reminder: ${visitor.name} still inside | ${companyName}`,
      html,
    });
    return { success: true };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

module.exports = {
  sendVisitorCheckinEmail,
  sendHostNotificationEmail,
  sendCheckoutReminderEmail,
  generateDigitalIDCard,
  generateQRCode,
};
