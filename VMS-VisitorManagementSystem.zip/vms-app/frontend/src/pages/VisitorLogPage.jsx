import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { visitorsAPI } from '../lib/api'
import { AppBar, Avatar, StatusBadge, formatTime, isOverdue } from '../components/ui'
import { Search, Filter } from 'lucide-react'

export default function VisitorLogPage() {
  const [search, setSearch] = useState('')
  const [filter, setFilter] = useState('all')

  const { data, isLoading } = useQuery({
    queryKey: ['all-visitors', filter],
    queryFn: () => visitorsAPI.getToday(),
    refetchInterval: 30_000,
  })

  const all = data?.data?.data || []
  const filtered = all.filter(v => {
    const matchSearch = !search || v.name.toLowerCase().includes(search.toLowerCase()) || v.visitor_id.toLowerCase().includes(search.toLowerCase())
    const matchFilter = filter === 'all' || (filter === 'in' && v.status === 'checked_in') || (filter === 'out' && v.status === 'checked_out')
    return matchSearch && matchFilter
  })

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <AppBar title="Visitor Log" subtitle={`${all.length} visitors today`} />

      <div className="bg-white border-b border-slate-100 px-4 py-3 space-y-2">
        <div className="relative">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input className="input-field pl-9" placeholder="Search visitors..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <div className="flex gap-2">
          {[['all','All'],['in','Inside'],['out','Checked Out']].map(([v,l]) => (
            <button key={v} onClick={() => setFilter(v)}
              className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-colors ${filter===v ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-500'}`}>
              {l}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 px-4 py-4 pb-8 space-y-2">
        {isLoading ? [1,2,3,4].map(i => <div key={i} className="bg-white rounded-2xl h-20 animate-pulse border border-slate-100" />) :
        filtered.length === 0 ? (
          <div className="text-center py-20">
            <div className="text-4xl mb-2">📋</div>
            <p className="text-slate-400 text-sm">No visitors found</p>
          </div>
        ) : filtered.map(v => (
          <div key={v.id} className={`bg-white rounded-2xl border p-4 ${v.status==='checked_in'&&isOverdue(v.checkin_time)?'border-red-200':'border-slate-100'}`}>
            <div className="flex items-start gap-3">
              <Avatar name={v.name} size="md" />
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <p className="font-bold text-slate-900 text-sm truncate">{v.name}</p>
                  <StatusBadge status={v.status} overdue={v.status==='checked_in'&&isOverdue(v.checkin_time)} />
                </div>
                <p className="text-xs text-slate-400 mt-0.5">{v.visitor_id} · {v.visitor_type_icon} {v.visitor_type_name}</p>
                <p className="text-xs text-slate-400 mt-0.5">Meets: {v.person_to_meet_name} ({v.person_dept})</p>
                <div className="flex gap-3 mt-1.5">
                  <span className="text-xs text-slate-500">In: {formatTime(v.checkin_time)}</span>
                  {v.checkout_time && <span className="text-xs text-slate-500">Out: {formatTime(v.checkout_time)}</span>}
                  {v.company && <span className="text-xs text-slate-400">· {v.company}</span>}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
