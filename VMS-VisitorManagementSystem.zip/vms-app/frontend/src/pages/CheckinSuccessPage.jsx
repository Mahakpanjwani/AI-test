import { useLocation, useNavigate } from 'react-router-dom'
import { useEffect } from 'react'
import { Home, UserCheck } from 'lucide-react'
import { formatDateTime } from '../components/ui'

function DigitalIDCard({ visitor }) {
  const initials = visitor.name.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase()

  return (
    <div className="relative rounded-2xl overflow-hidden text-white"
      style={{ background: 'linear-gradient(135deg, #1a56db 0%, #1d4ed8 100%)' }}>
      {/* Decorative circles */}
      <div className="absolute -top-8 -right-8 w-32 h-32 bg-white/10 rounded-full" />
      <div className="absolute -bottom-6 -left-6 w-24 h-24 bg-white/5 rounded-full" />

      <div className="relative p-5">
        {/* Header */}
        <div className="flex items-start justify-between mb-5">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-[2px] text-blue-200">VISITOR PASS</p>
            <p className="text-sm font-bold mt-0.5">Company HQ</p>
          </div>
          <div className="w-14 h-14 bg-white/20 border-2 border-white/40 rounded-full flex items-center justify-center text-xl font-extrabold">
            {initials}
          </div>
        </div>

        {/* Name & details */}
        <div className="mb-5">
          <h2 className="text-xl font-extrabold mb-1">{visitor.name}</h2>
          <p className="text-blue-200 text-xs mb-0.5">📞 {visitor.phone}</p>
          {visitor.company && <p className="text-blue-200 text-xs mb-0.5">🏢 {visitor.company}</p>}
          <p className="text-blue-200 text-xs">🤝 Meeting: {visitor.person_to_meet_name}</p>
        </div>

        {/* Footer */}
        <div className="border-t border-white/20 pt-4 flex items-end justify-between">
          <div>
            <p className="text-[9px] uppercase tracking-widest text-blue-300 mb-1">VISITOR ID</p>
            <p className="text-base font-extrabold font-mono">{visitor.visitor_id}</p>
            <p className="text-blue-200 text-[10px] mt-1">⏰ {formatDateTime(visitor.checkin_time)}</p>
          </div>
          <div className="text-right">
            <div className="inline-block bg-white/20 border border-white/30 rounded-xl px-3 py-1.5">
              <p className="text-xs font-bold">{visitor.visitor_type_name}</p>
            </div>
            <p className="text-[10px] text-blue-300 mt-1">Dept: {visitor.person_dept}</p>
          </div>
        </div>
      </div>
    </div>
  )
}

export default function CheckinSuccessPage() {
  const location = useLocation()
  const navigate = useNavigate()
  const visitor = location.state?.visitor

  useEffect(() => {
    if (!visitor) navigate('/', { replace: true })
  }, [visitor, navigate])

  if (!visitor) return null

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Success header */}
      <div className="bg-emerald-500 px-5 py-10 text-center">
        <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
          <UserCheck size={32} className="text-white" />
        </div>
        <h1 className="text-white text-xl font-extrabold">Check-In Successful!</h1>
        <p className="text-emerald-100 text-sm mt-1">{visitor.visitor_id}</p>
      </div>

      <div className="flex-1 px-4 py-5 pb-32 space-y-4">
        {/* Email status */}
        <div className="bg-white rounded-2xl border border-slate-100 p-4">
          <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Notifications Sent</p>
          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-emerald-100 rounded-full flex items-center justify-center">
                <span className="text-sm">✉️</span>
              </div>
              <div>
                <p className="text-sm font-semibold text-slate-800">Visitor Confirmation</p>
                <p className="text-xs text-slate-400">Digital ID card sent to {visitor.email || visitor.phone}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                <span className="text-sm">🔔</span>
              </div>
              <div>
                <p className="text-sm font-semibold text-slate-800">Host Notified</p>
                <p className="text-xs text-slate-400">{visitor.person_to_meet_name} alerted at reception</p>
              </div>
            </div>
          </div>
        </div>

        {/* Digital ID Card */}
        <div>
          <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Digital Visitor Pass</p>
          <DigitalIDCard visitor={visitor} />
          <p className="text-xs text-slate-400 text-center mt-2">
            Show this pass for any verification during the visit
          </p>
        </div>

        {/* Checkout reminder */}
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4">
          <div className="flex gap-3 items-start">
            <span className="text-lg">⚠️</span>
            <div>
              <p className="text-sm font-bold text-amber-800">Checkout is Mandatory</p>
              <p className="text-xs text-amber-700 mt-0.5 leading-relaxed">
                Remind the visitor to check out at reception before leaving. Automatic reminders will be sent after 4 hours.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom actions */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white border-t border-slate-100 space-y-2" style={{ maxWidth: 430, margin: '0 auto' }}>
        <button onClick={() => navigate('/checkin')} className="btn-primary">
          + Register Another Visitor
        </button>
        <button onClick={() => navigate('/')} className="btn-ghost w-full">
          <Home size={18} /> Back to Home
        </button>
      </div>
    </div>
  )
}
