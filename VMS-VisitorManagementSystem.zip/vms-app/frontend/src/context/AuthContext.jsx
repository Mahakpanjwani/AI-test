import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { authAPI } from '../lib/api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser]     = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('vms_token');
    const stored = localStorage.getItem('vms_user');
    if (token && stored) {
      try { setUser(JSON.parse(stored)); } catch {}
      // Verify token is still valid
      authAPI.me()
        .then(r => { setUser(r.data.user); localStorage.setItem('vms_user', JSON.stringify(r.data.user)); })
        .catch(() => { localStorage.removeItem('vms_token'); localStorage.removeItem('vms_user'); setUser(null); })
        .finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, []);

  const login = useCallback(async (employee_id, password) => {
    const res = await authAPI.login({ employee_id, password });
    const { token, user } = res.data;
    localStorage.setItem('vms_token', token);
    localStorage.setItem('vms_user', JSON.stringify(user));
    setUser(user);
    return user;
  }, []);

  const logout = useCallback(() => {
    authAPI.logout().catch(() => {});
    localStorage.removeItem('vms_token');
    localStorage.removeItem('vms_user');
    setUser(null);
  }, []);

  return (
    <AuthContext.Provider value={{ user, loading, login, logout, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
};
