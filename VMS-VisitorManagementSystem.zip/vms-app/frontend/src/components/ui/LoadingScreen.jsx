export default function LoadingScreen() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-blue-600">
      <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center mb-4 animate-pulse">
        <span className="text-3xl">🏢</span>
      </div>
      <div className="flex gap-1">
        {[0,1,2].map(i => (
          <div key={i} className="w-2 h-2 bg-white/60 rounded-full animate-bounce"
            style={{ animationDelay: `${i * 0.15}s` }} />
        ))}
      </div>
    </div>
  )
}
