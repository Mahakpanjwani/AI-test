import { useState, useEffect, useRef } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import { useQuery, useMutation } from '@tanstack/react-query'
import { visitorsAPI, employeesAPI } from '../lib/api'
import { AppBar, FormField, Avatar } from '../components/ui'
import { Search, Upload, Check, ChevronDown, Clock, X } from 'lucide-react'
import toast from 'react-hot-toast'

const ID_PROOF_TYPES = ['Aadhar Card', 'PAN Card', 'Passport', 'Driving License', 'Voter ID', 'Employee ID', 'Other']

export default function CheckinFormPage() {
  const navigate = useNavigate()
  const location = useLocation()
  const visitorType = location.state?.visitorType
  const fileRef = useRef(null)

  const [form, setForm] = useState({
    name: '', phone: '', email: '', company: '',
    person_to_meet_id: '', purpose: '',
    id_proof_type: '', id_proof_number: '', notes: '',
  })
  const [empSearch, setEmpSearch] = useState('')
  const [selectedEmp, setSelectedEmp] = useState(null)
  const [showEmpList, setShowEmpList] = useState(false)
  const [idFile, setIdFile] = useState(null)
  const [errors, setErrors] = useState({})
  const [currentTime, setCurrentTime] = useState(new Date())

  useEffect(() => {
    if (!visitorType) { navigate('/checkin', { replace: true }); return }
    const t = setInterval(() => setCurrentTime(new Date()), 1000)
    return () => clearInterval(t)
  }, [visitorType, navigate])

  const { data: empData } = useQuery({
    queryKey: ['employees', empSearch],
    queryFn: () => employeesAPI.getAll({ search: empSearch }),
    staleTime: 30_000,
  })
  const employees = empData?.data?.data || []

  const checkinMutation = useMutation({
    mutationFn: (fd) => visitorsAPI.checkin(fd),
    onSuccess: (res) => {
      toast.success('Check-in successful!')
      navigate('/checkin/success', { state: { visitor: res.data.data }, replace: true })
    },
    onError: (err) => {
      toast.error(err.response?.data?.message || 'Check-in failed')
    }
  })

  const sf = (k, v) => {
    setForm(f => ({ ...f, [k]: v }))
    if (errors[k]) setErrors(e => ({ ...e, [k]: '' }))
  }

  const validate = () => {
    const e = {}
    if (!form.name.trim()) e.name = 'Full name is required'
    if (!form.phone.trim()) e.phone = 'Phone number is required'
    if (form.phone && !/^\+?[\d\s-]{8,15}$/.test(form.phone)) e.phone = 'Enter a valid phone number'
    if (form.email && !/\S+@\S+\.\S+/.test(form.email)) e.email = 'Enter a valid email'
    if (!selectedEmp) e.person_to_meet_id = 'Please select person to meet'
    setErrors(e)
    return Object.keys(e).length === 0
  }

  const handleSubmit = () => {
    if (!validate()) { toast.error('Please fix the errors'); return }
    const fd = new FormData()
    fd.append('visitor_type_id', visitorType.id)
    fd.append('name', form.name.trim())
    fd.append('phone', form.phone.trim())
    fd.append('email', form.email)
    fd.append('company', form.company)
    fd.append('person_to_meet_id', selectedEmp.id)
    fd.append('purpose', form.purpose)
    fd.append('id_proof_type', form.id_proof_type)
    fd.append('id_proof_number', form.id_proof_number)
    fd.append('notes', form.notes)
    if (idFile) fd.append('id_proof_file', idFile)
    checkinMutation.mutate(fd)
  }

  if (!visitorType) return null

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <AppBar
        title="Visitor Details"
        subtitle={`${visitorType.icon} ${visitorType.name}`}
      />

      {/* Type indicator */}
      <div className="px-4 pt-4 pb-2">
        <div className="flex items-center gap-2 bg-blue-50 border border-blue-100 rounded-xl px-4 py-2.5">
          <span className="text-xl">{visitorType.icon}</span>
          <div>
            <p className="text-xs text-blue-500 font-medium">Visit type</p>
            <p className="text-sm font-bold text-blue-700">{visitorType.name}</p>
          </div>
        </div>
      </div>

      <div className="flex-1 px-4 pb-32 pt-2 space-y-1">

        {/* Personal Info */}
        <div className="bg-white rounded-2xl p-4 border border-slate-100">
          <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">Personal Information</p>

          <FormField label="Full Name" required error={errors.name}>
            <input className="input-field" placeholder="Enter visitor's full name"
              value={form.name} onChange={e => sf('name', e.target.value)} />
          </FormField>

          <div className="grid grid-cols-2 gap-3">
            <FormField label="Phone Number" required error={errors.phone}>
              <input className="input-field" placeholder="+91 XXXXX XXXXX" type="tel"
                value={form.phone} onChange={e => sf('phone', e.target.value)} />
            </FormField>
            <FormField label="Email Address" error={errors.email}>
              <input className="input-field" placeholder="visitor@email.com" type="email"
                value={form.email} onChange={e => sf('email', e.target.value)} />
            </FormField>
          </div>

          <FormField label="Company / Organisation">
            <input className="input-field" placeholder="Where are they from?"
              value={form.company} onChange={e => sf('company', e.target.value)} />
          </FormField>
        </div>

        {/* Person to Meet */}
        <div className="bg-white rounded-2xl p-4 border border-slate-100 border-t-0 rounded-t-none" style={{ marginTop: 1 }}>
          <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">Person to Meet</p>

          {selectedEmp ? (
            <div className="flex items-center gap-3 bg-blue-50 border border-blue-100 rounded-xl p-3">
              <Avatar name={selectedEmp.name} size="md" />
              <div className="flex-1">
                <p className="text-sm font-bold text-slate-900">{selectedEmp.name}</p>
                <p className="text-xs text-slate-500">{selectedEmp.designation} · {selectedEmp.department}</p>
              </div>
              <button onClick={() => { setSelectedEmp(null); sf('person_to_meet_id', '') }}
                className="w-7 h-7 bg-slate-200 rounded-full flex items-center justify-center text-slate-500">
                <X size={14} />
              </button>
            </div>
          ) : (
            <div>
              <div className="relative mb-2">
                <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  className="input-field pl-9"
                  placeholder="Search by name or department..."
                  value={empSearch}
                  onChange={e => { setEmpSearch(e.target.value); setShowEmpList(true) }}
                  onFocus={() => setShowEmpList(true)}
                />
              </div>
              {errors.person_to_meet_id && <p className="text-xs text-red-500 mb-2">{errors.person_to_meet_id}</p>}
              {showEmpList && (
                <div className="border border-slate-200 rounded-xl overflow-hidden max-h-48 overflow-y-auto">
                  {employees.length === 0 ? (
                    <div className="px-4 py-6 text-center text-sm text-slate-400">No employees found</div>
                  ) : employees.map(emp => (
                    <button key={emp.id} type="button"
                      onClick={() => { setSelectedEmp(emp); sf('person_to_meet_id', emp.id); setShowEmpList(false); setEmpSearch('') }}
                      className="w-full flex items-center gap-3 px-4 py-3 hover:bg-slate-50 border-b border-slate-50 last:border-0 text-left active:bg-blue-50">
                      <Avatar name={emp.name} size="sm" />
                      <div>
                        <p className="text-sm font-semibold text-slate-900">{emp.name}</p>
                        <p className="text-xs text-slate-400">{emp.designation} · {emp.department}</p>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Check-in Details */}
        <div className="bg-white rounded-2xl p-4 border border-slate-100 mt-1">
          <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">Visit Details</p>

          <FormField label="Check-in Time">
            <div className="input-field flex items-center gap-2 bg-slate-100 text-slate-700 cursor-default">
              <Clock size={16} className="text-slate-400" />
              <span className="font-semibold">{currentTime.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true })}</span>
              <span className="text-slate-400 text-xs ml-1">(Auto)</span>
            </div>
          </FormField>

          <FormField label="Purpose of Visit">
            <input className="input-field" placeholder="e.g. Project discussion, Interview, Delivery..."
              value={form.purpose} onChange={e => sf('purpose', e.target.value)} />
          </FormField>

          <FormField label="Additional Notes">
            <textarea className="input-field resize-none" rows={2} placeholder="Any special instructions..."
              value={form.notes} onChange={e => sf('notes', e.target.value)} />
          </FormField>
        </div>

        {/* ID Proof */}
        <div className="bg-white rounded-2xl p-4 border border-slate-100 mt-1">
          <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">Identity Verification</p>

          <div className="grid grid-cols-2 gap-3 mb-3">
            <FormField label="ID Proof Type">
              <div className="relative">
                <select className="input-field appearance-none pr-8"
                  value={form.id_proof_type} onChange={e => sf('id_proof_type', e.target.value)}>
                  <option value="">Select type</option>
                  {ID_PROOF_TYPES.map(t => <option key={t}>{t}</option>)}
                </select>
                <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
              </div>
            </FormField>
            <FormField label="ID Number">
              <input className="input-field" placeholder="XXXX-XXXX"
                value={form.id_proof_number} onChange={e => sf('id_proof_number', e.target.value)} />
            </FormField>
          </div>

          <FormField label="Upload ID Proof">
            <button type="button" onClick={() => fileRef.current?.click()}
              className={`w-full border-2 border-dashed rounded-xl p-5 text-center transition-all ${idFile ? 'border-emerald-300 bg-emerald-50' : 'border-slate-200 bg-slate-50 active:border-blue-300'}`}>
              <input ref={fileRef} type="file" className="hidden" accept="image/*,.pdf"
                onChange={e => setIdFile(e.target.files[0])} />
              <div className="text-2xl mb-1">{idFile ? '✅' : '📎'}</div>
              <p className="text-sm font-semibold text-slate-600">{idFile ? idFile.name : 'Tap to upload'}</p>
              <p className="text-xs text-slate-400 mt-0.5">{idFile ? 'Tap to change' : 'Aadhar, PAN, Passport, etc.'}</p>
            </button>
          </FormField>
        </div>
      </div>

      {/* Bottom Submit */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white border-t border-slate-100 shadow-xl" style={{ maxWidth: 430, margin: '0 auto' }}>
        <button onClick={handleSubmit} disabled={checkinMutation.isPending} className="btn-primary">
          {checkinMutation.isPending ? (
            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          ) : (
            <><Check size={18} /> Complete Check-In & Send Emails</>
          )}
        </button>
        <p className="text-xs text-slate-400 text-center mt-2">
          ✉️ Auto emails will be sent to visitor & host
        </p>
      </div>
    </div>
  )
}
