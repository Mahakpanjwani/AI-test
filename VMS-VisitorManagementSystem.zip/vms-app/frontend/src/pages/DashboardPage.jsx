import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { visitorsAPI } from '../lib/api'
import { AppBar, StatCard, formatTime, isOverdue } from '../components/ui'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'

export default function DashboardPage() {
  const [tab, setTab] = useState('today')

  const { data: statsData, isLoading } = useQuery({
    queryKey: ['stats'],
    queryFn: () => visitorsAPI.getStats(),
    refetchInterval: 60_000,
  })

  const stats = statsData?.data?.data || {}
  const today = stats.today || {}
  const byType = stats.byType || []
  const byHour = stats.byHour || []
  const topHosts = stats.topHosts || []
  const last7days = stats.last7days || []

  const COLORS = ['#1a56db','#059669','#d97706','#7c3aed','#dc2626','#0891b2','#374151','#be185d']

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <AppBar title="Dashboard" subtitle="Visitor Analytics" />

      {/* Tabs */}
      <div className="flex bg-white border-b border-slate-100 px-4">
        {['today','analytics','hosts'].map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`flex-1 py-3 text-xs font-bold capitalize transition-colors border-b-2 ${tab===t ? 'text-blue-600 border-blue-600' : 'text-slate-400 border-transparent'}`}>
            {t === 'today' ? "Today's Stats" : t === 'analytics' ? 'Analytics' : 'Top Hosts'}
          </button>
        ))}
      </div>

      <div className="flex-1 px-4 py-4 pb-8 space-y-4">

        {tab === 'today' && (
          <>
            <div className="grid grid-cols-2 gap-3">
              <StatCard label="Total Visitors" value={today.total ?? 0} icon="👥" color="blue" />
              <StatCard label="Currently Inside" value={today.active ?? 0} icon="🏢" color="green" />
              <StatCard label="Checked Out" value={today.checkedOut ?? 0} icon="🚪" color="amber" />
              <StatCard label="Overdue" value={today.overdue ?? 0} icon="⚠️" color="red" />
            </div>

            <div className="bg-white rounded-2xl border border-slate-100 p-4">
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Checkout Compliance</p>
              <div className="flex items-end gap-3 mb-2">
                <span className="text-3xl font-extrabold text-slate-900">{today.compliance ?? 0}%</span>
                <span className="text-sm text-slate-400 mb-1">visitors checked out properly</span>
              </div>
              <div className="h-3 bg-slate-100 rounded-full overflow-hidden">
                <div className="h-full rounded-full transition-all duration-700"
                  style={{ width: `${today.compliance ?? 0}%`, background: (today.compliance ?? 0) >= 80 ? '#059669' : (today.compliance ?? 0) >= 50 ? '#d97706' : '#dc2626' }} />
              </div>
            </div>

            {byType.length > 0 && (
              <div className="bg-white rounded-2xl border border-slate-100 p-4">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">By Visitor Type</p>
                {byType.map((t, i) => (
                  <div key={t.name} className="flex items-center gap-3 mb-2.5">
                    <span className="text-lg w-7">{t.icon}</span>
                    <div className="flex-1">
                      <div className="flex justify-between text-xs mb-1">
                        <span className="font-medium text-slate-700">{t.name}</span>
                        <span className="font-bold text-slate-900">{t.count}</span>
                      </div>
                      <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                        <div className="h-full rounded-full" style={{ width: `${(t.count / (today.total || 1)) * 100}%`, background: COLORS[i % COLORS.length] }} />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {byHour.length > 0 && (
              <div className="bg-white rounded-2xl border border-slate-100 p-4">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">Check-ins by Hour</p>
                <ResponsiveContainer width="100%" height={140}>
                  <BarChart data={byHour} margin={{ left: -20 }}>
                    <XAxis dataKey="hour" tick={{ fontSize: 10 }} tickFormatter={h => `${h}:00`} />
                    <YAxis tick={{ fontSize: 10 }} />
                    <Tooltip formatter={(v) => [v, 'Visitors']} labelFormatter={l => `${l}:00`} />
                    <Bar dataKey="count" fill="#1a56db" radius={[4,4,0,0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </>
        )}

        {tab === 'analytics' && (
          <>
            <div className="bg-white rounded-2xl border border-slate-100 p-4">
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">Last 7 Days</p>
              {last7days.length > 0 ? (
                <ResponsiveContainer width="100%" height={160}>
                  <BarChart data={last7days} margin={{ left: -20 }}>
                    <XAxis dataKey="date" tick={{ fontSize: 9 }} tickFormatter={d => new Date(d).toLocaleDateString('en-IN',{day:'2-digit',month:'short'})} />
                    <YAxis tick={{ fontSize: 10 }} />
                    <Tooltip formatter={(v) => [v, 'Visitors']} />
                    <Bar dataKey="count" fill="#1a56db" radius={[4,4,0,0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : <p className="text-sm text-slate-400 text-center py-8">No data available</p>}
            </div>

            {byType.length > 0 && (
              <div className="bg-white rounded-2xl border border-slate-100 p-4">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">Visitor Type Split</p>
                <ResponsiveContainer width="100%" height={180}>
                  <PieChart>
                    <Pie data={byType} dataKey="count" nameKey="name" cx="50%" cy="50%" outerRadius={70} label={({ name, percent }) => `${name.split('/')[0]} ${(percent*100).toFixed(0)}%`} labelLine={false}>
                      {byType.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            )}

            <div className="bg-white rounded-2xl border border-slate-100 p-4">
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Avg. Visit Duration</p>
              <div className="text-3xl font-extrabold text-slate-900">{today.avgDuration ?? 0} <span className="text-lg font-medium text-slate-400">minutes</span></div>
            </div>
          </>
        )}

        {tab === 'hosts' && (
          <div className="bg-white rounded-2xl border border-slate-100 p-4">
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">Most Visited Employees</p>
            {topHosts.length === 0 ? (
              <p className="text-sm text-slate-400 text-center py-8">No data yet</p>
            ) : topHosts.map((h, i) => (
              <div key={h.name} className="flex items-center gap-3 mb-3 last:mb-0">
                <div className="w-7 h-7 bg-blue-100 text-blue-700 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0">
                  {i + 1}
                </div>
                <div className="flex-1">
                  <div className="flex justify-between text-sm mb-1">
                    <span className="font-semibold text-slate-800">{h.name}</span>
                    <span className="font-bold text-blue-600">{h.visit_count}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-slate-400">{h.department}</span>
                    <div className="h-1.5 w-24 bg-slate-100 rounded-full overflow-hidden">
                      <div className="h-full bg-blue-500 rounded-full" style={{ width: `${(h.visit_count / (topHosts[0]?.visit_count || 1)) * 100}%` }} />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
