#!/bin/bash
# VMS Quick Start Script
echo "🏢 Starting Visitor Management System..."

# Start backend
echo "📡 Starting backend on port 5000..."
cd backend && npm install && npm start &
BACKEND_PID=$!

# Wait for backend
sleep 3

# Start frontend
echo "🌐 Starting frontend on port 3000..."
cd ../frontend && npm install && npm run dev &
FRONTEND_PID=$!

echo ""
echo "✅ VMS is running!"
echo "   Frontend: http://localhost:3000"
echo "   Backend:  http://localhost:5000"
echo "   Login:    REC001 / admin123"
echo ""
echo "Press Ctrl+C to stop both servers"

# Wait for Ctrl+C
trap "kill $BACKEND_PID $FRONTEND_PID; exit" INT
wait
