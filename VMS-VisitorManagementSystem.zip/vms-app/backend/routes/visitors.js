const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { getDb } = require('../database');
const authMiddleware = require('../middleware/auth');
const { sendVisitorCheckinEmail, sendHostNotificationEmail, generateQRCode } = require('../utils/email');

// Multer for ID proof uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadPath = process.env.UPLOAD_PATH || './uploads';
    if (!fs.existsSync(uploadPath)) fs.mkdirSync(uploadPath, { recursive: true });
    cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `idproof_${Date.now()}_${Math.random().toString(36).slice(2)}${ext}`);
  },
});
const upload = multer({
  storage,
  limits: { fileSize: parseInt(process.env.UPLOAD_MAX_SIZE) || 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = ['image/jpeg', 'image/png', 'image/jpg', 'application/pdf'];
    if (allowed.includes(file.mimetype)) cb(null, true);
    else cb(new Error('Only images and PDFs allowed'));
  },
});

function generateVisitorId() {
  const now = new Date();
  const date = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}`;
  const rand = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `VIS-${date}-${rand}`;
}

function buildVisitorQuery(filters) {
  const db = getDb();
  let query = `
    SELECT
      v.*,
      e.name AS person_to_meet_name,
      e.email AS person_to_meet_email,
      e.department AS person_dept,
      e.phone AS person_phone,
      vt.name AS visitor_type_name,
      vt.icon AS visitor_type_icon,
      vt.color AS visitor_type_color,
      r1.name AS checkin_by_name,
      r2.name AS checkout_by_name
    FROM visitors v
    LEFT JOIN employees e ON v.person_to_meet_id = e.id
    LEFT JOIN visitor_types vt ON v.visitor_type_id = vt.id
    LEFT JOIN receptionists r1 ON v.checkin_by = r1.id
    LEFT JOIN receptionists r2 ON v.checkout_by = r2.id
    WHERE 1=1
  `;
  const params = [];

  if (filters.status) { query += ' AND v.status = ?'; params.push(filters.status); }
  if (filters.date) {
    query += ' AND DATE(v.checkin_time) = ?';
    params.push(filters.date);
  }
  if (filters.today) {
    query += " AND DATE(v.checkin_time) = DATE('now', 'localtime')";
  }
  if (filters.search) {
    query += ' AND (v.name LIKE ? OR v.visitor_id LIKE ? OR v.phone LIKE ? OR v.company LIKE ?)';
    const s = `%${filters.search}%`;
    params.push(s, s, s, s);
  }
  if (filters.visitor_type_id) { query += ' AND v.visitor_type_id = ?'; params.push(filters.visitor_type_id); }
  if (filters.person_to_meet_id) { query += ' AND v.person_to_meet_id = ?'; params.push(filters.person_to_meet_id); }

  query += ' ORDER BY v.checkin_time DESC';

  if (filters.limit) {
    query += ' LIMIT ?';
    params.push(parseInt(filters.limit));
    if (filters.offset) { query += ' OFFSET ?'; params.push(parseInt(filters.offset)); }
  }

  return db.prepare(query).all(...params);
}

// GET /api/visitors - list with filters
router.get('/', authMiddleware, (req, res) => {
  try {
    const visitors = buildVisitorQuery(req.query);
    res.json({ success: true, data: visitors, count: visitors.length });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// GET /api/visitors/active - currently checked in
router.get('/active', authMiddleware, (req, res) => {
  try {
    const visitors = buildVisitorQuery({ status: 'checked_in', ...req.query });
    res.json({ success: true, data: visitors, count: visitors.length });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// GET /api/visitors/today - today's visitors
router.get('/today', authMiddleware, (req, res) => {
  try {
    const visitors = buildVisitorQuery({ today: true, ...req.query });
    res.json({ success: true, data: visitors, count: visitors.length });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// GET /api/visitors/stats - dashboard stats
router.get('/stats', authMiddleware, (req, res) => {
  try {
    const db = getDb();
    const { date } = req.query;
    const targetDate = date || new Date().toISOString().split('T')[0];

    const total = db.prepare("SELECT COUNT(*) as count FROM visitors WHERE DATE(checkin_time) = ?").get(targetDate);
    const active = db.prepare("SELECT COUNT(*) as count FROM visitors WHERE DATE(checkin_time) = ? AND status = 'checked_in'").get(targetDate);
    const checkedOut = db.prepare("SELECT COUNT(*) as count FROM visitors WHERE DATE(checkin_time) = ? AND status = 'checked_out'").get(targetDate);

    const fourHoursAgo = new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString();
    const overdue = db.prepare("SELECT COUNT(*) as count FROM visitors WHERE status = 'checked_in' AND checkin_time < ?").get(fourHoursAgo);

    const byType = db.prepare(`
      SELECT vt.name, vt.icon, vt.color, COUNT(*) as count
      FROM visitors v JOIN visitor_types vt ON v.visitor_type_id = vt.id
      WHERE DATE(v.checkin_time) = ?
      GROUP BY vt.id ORDER BY count DESC
    `).all(targetDate);

    const byHour = db.prepare(`
      SELECT strftime('%H', checkin_time) as hour, COUNT(*) as count
      FROM visitors WHERE DATE(checkin_time) = ?
      GROUP BY hour ORDER BY hour
    `).all(targetDate);

    const avgDuration = db.prepare(`
      SELECT AVG((julianday(checkout_time) - julianday(checkin_time)) * 24 * 60) as avg_minutes
      FROM visitors WHERE DATE(checkin_time) = ? AND status = 'checked_out'
    `).get(targetDate);

    const topHosts = db.prepare(`
      SELECT e.name, e.department, COUNT(*) as visit_count
      FROM visitors v JOIN employees e ON v.person_to_meet_id = e.id
      WHERE DATE(v.checkin_time) = ?
      GROUP BY e.id ORDER BY visit_count DESC LIMIT 5
    `).all(targetDate);

    const last7days = db.prepare(`
      SELECT DATE(checkin_time) as date, COUNT(*) as count
      FROM visitors
      WHERE checkin_time >= datetime('now', '-7 days')
      GROUP BY DATE(checkin_time) ORDER BY date
    `).all();

    const checkoutCompliance = db.prepare(`
      SELECT
        COUNT(*) as total,
        SUM(CASE WHEN status='checked_out' THEN 1 ELSE 0 END) as checked_out
      FROM visitors WHERE DATE(checkin_time) = ?
    `).get(targetDate);

    res.json({
      success: true,
      data: {
        today: {
          total: total.count,
          active: active.count,
          checkedOut: checkedOut.count,
          overdue: overdue.count,
          avgDuration: Math.round(avgDuration?.avg_minutes || 0),
          compliance: checkoutCompliance.total > 0
            ? Math.round((checkoutCompliance.checked_out / checkoutCompliance.total) * 100)
            : 0,
        },
        byType,
        byHour,
        topHosts,
        last7days,
      }
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// GET /api/visitors/:id
router.get('/:id', authMiddleware, (req, res) => {
  try {
    const db = getDb();
    const visitor = db.prepare(`
      SELECT v.*, e.name AS person_to_meet_name, e.email AS person_to_meet_email,
      e.department AS person_dept, vt.name AS visitor_type_name, vt.icon AS visitor_type_icon
      FROM visitors v
      LEFT JOIN employees e ON v.person_to_meet_id = e.id
      LEFT JOIN visitor_types vt ON v.visitor_type_id = vt.id
      WHERE v.id = ? OR v.visitor_id = ?
    `).get(req.params.id, req.params.id);

    if (!visitor) return res.status(404).json({ success: false, message: 'Visitor not found' });
    res.json({ success: true, data: visitor });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// POST /api/visitors/checkin - main check-in
router.post('/checkin', authMiddleware, upload.single('id_proof_file'), async (req, res) => {
  try {
    const {
      visitor_type_id, name, phone, email, company,
      person_to_meet_id, purpose, id_proof_type, id_proof_number, notes
    } = req.body;

    if (!visitor_type_id || !name || !phone || !person_to_meet_id) {
      return res.status(400).json({ success: false, message: 'Type, name, phone, person to meet are required' });
    }

    const db = getDb();
    const employee = db.prepare('SELECT * FROM employees WHERE id = ? AND is_active = 1').get(person_to_meet_id);
    if (!employee) return res.status(404).json({ success: false, message: 'Employee not found' });

    const visitorType = db.prepare('SELECT * FROM visitor_types WHERE id = ?').get(visitor_type_id);
    if (!visitorType) return res.status(404).json({ success: false, message: 'Visitor type not found' });

    const visitorId = generateVisitorId();
    const idProofFile = req.file ? req.file.filename : null;

    // Generate QR code
    const qrData = JSON.stringify({ visitorId, name, checkinTime: new Date().toISOString() });
    const qrCode = await generateQRCode(qrData).catch(() => null);

    const result = db.prepare(`
      INSERT INTO visitors (
        visitor_id, visitor_type_id, name, phone, email, company,
        person_to_meet_id, purpose, id_proof_type, id_proof_file, id_proof_number,
        notes, qr_code, checkin_by, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'checked_in')
    `).run(
      visitorId, visitor_type_id, name.trim(), phone.trim(), email || null,
      company || null, person_to_meet_id, purpose || null,
      id_proof_type || null, idProofFile, id_proof_number || null,
      notes || null, qrCode, req.user.id
    );

    const newVisitor = db.prepare(`
      SELECT v.*, e.name AS person_to_meet_name, e.email AS person_to_meet_email,
      e.department AS person_dept, vt.name AS visitor_type_name, vt.icon AS visitor_type_icon
      FROM visitors v
      LEFT JOIN employees e ON v.person_to_meet_id = e.id
      LEFT JOIN visitor_types vt ON v.visitor_type_id = vt.id
      WHERE v.id = ?
    `).get(result.lastInsertRowid);

    // Send emails asynchronously (don't block response)
    const emailResults = { visitor: false, host: false };

    if (email) {
      sendVisitorCheckinEmail(newVisitor).then(r => {
        const status = r.success ? 'sent' : 'failed';
        db.prepare('UPDATE visitors SET email_sent_visitor = ? WHERE id = ?').run(r.success ? 1 : 0, result.lastInsertRowid);
        db.prepare('INSERT INTO email_logs (visitor_id, recipient_email, recipient_type, subject, status, sent_at) VALUES (?, ?, ?, ?, ?, ?)').run(
          result.lastInsertRowid, email, 'visitor', 'Check-in Confirmation', status, new Date().toISOString()
        );
      });
    }

    sendHostNotificationEmail(newVisitor).then(r => {
      db.prepare('UPDATE visitors SET email_sent_host = ? WHERE id = ?').run(r.success ? 1 : 0, result.lastInsertRowid);
      db.prepare('INSERT INTO email_logs (visitor_id, recipient_email, recipient_type, subject, status, sent_at) VALUES (?, ?, ?, ?, ?, ?)').run(
        result.lastInsertRowid, employee.email, 'host', 'Visitor Arrival', r.success ? 'sent' : 'failed', new Date().toISOString()
      );
    });

    res.status(201).json({
      success: true,
      message: 'Visitor checked in successfully',
      data: newVisitor,
      emailStatus: emailResults,
    });
  } catch (err) {
    console.error('Check-in error:', err);
    res.status(500).json({ success: false, message: 'Server error during check-in' });
  }
});

// PUT /api/visitors/:id/checkout
router.put('/:id/checkout', authMiddleware, (req, res) => {
  try {
    const db = getDb();
    const visitor = db.prepare("SELECT * FROM visitors WHERE (id = ? OR visitor_id = ?) AND status = 'checked_in'")
      .get(req.params.id, req.params.id);

    if (!visitor) return res.status(404).json({ success: false, message: 'Active visitor not found' });

    db.prepare(`
      UPDATE visitors
      SET status = 'checked_out', checkout_time = CURRENT_TIMESTAMP, checkout_by = ?
      WHERE id = ?
    `).run(req.user.id, visitor.id);

    const updated = db.prepare(`
      SELECT v.*, e.name AS person_to_meet_name, vt.name AS visitor_type_name
      FROM visitors v
      LEFT JOIN employees e ON v.person_to_meet_id = e.id
      LEFT JOIN visitor_types vt ON v.visitor_type_id = vt.id
      WHERE v.id = ?
    `).get(visitor.id);

    // Calculate duration
    const durationMs = new Date(updated.checkout_time) - new Date(updated.checkin_time);
    const durationMin = Math.round(durationMs / 60000);

    res.json({
      success: true,
      message: 'Visitor checked out successfully',
      data: { ...updated, duration_minutes: durationMin },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// GET /api/visitors/types/all
router.get('/types/all', authMiddleware, (req, res) => {
  try {
    const db = getDb();
    const types = db.prepare('SELECT * FROM visitor_types WHERE is_active = 1 ORDER BY id').all();
    res.json({ success: true, data: types });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

module.exports = router;
