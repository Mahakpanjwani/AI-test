const express = require('express');
const router = express.Router();
const { getDb } = require('../database');
const authMiddleware = require('../middleware/auth');

// GET /api/employees - list all active employees (with search)
router.get('/', authMiddleware, (req, res) => {
  try {
    const db = getDb();
    const { search, department } = req.query;
    let query = 'SELECT id, name, email, phone, department, designation, employee_code, avatar_initials FROM employees WHERE is_active = 1';
    const params = [];

    if (search) {
      query += ' AND (name LIKE ? OR department LIKE ? OR designation LIKE ? OR employee_code LIKE ?)';
      const s = `%${search}%`;
      params.push(s, s, s, s);
    }
    if (department) {
      query += ' AND department = ?';
      params.push(department);
    }
    query += ' ORDER BY name ASC';

    const employees = db.prepare(query).all(...params);
    res.json({ success: true, data: employees });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// GET /api/employees/departments
router.get('/departments', authMiddleware, (req, res) => {
  try {
    const db = getDb();
    const depts = db.prepare('SELECT DISTINCT department FROM employees WHERE is_active = 1 ORDER BY department').all();
    res.json({ success: true, data: depts.map(d => d.department) });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// GET /api/employees/:id
router.get('/:id', authMiddleware, (req, res) => {
  try {
    const db = getDb();
    const emp = db.prepare('SELECT id, name, email, phone, department, designation, employee_code, avatar_initials FROM employees WHERE id = ? AND is_active = 1').get(req.params.id);
    if (!emp) return res.status(404).json({ success: false, message: 'Employee not found' });
    res.json({ success: true, data: emp });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// POST /api/employees - add employee
router.post('/', authMiddleware, (req, res) => {
  try {
    const { name, email, phone, department, designation, employee_code } = req.body;
    if (!name || !email || !department) {
      return res.status(400).json({ success: false, message: 'Name, email, department required' });
    }
    const initials = name.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();
    const db = getDb();
    const result = db.prepare(
      'INSERT INTO employees (name, email, phone, department, designation, employee_code, avatar_initials) VALUES (?, ?, ?, ?, ?, ?, ?)'
    ).run(name, email, phone, department, designation, employee_code, initials);

    const emp = db.prepare('SELECT * FROM employees WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json({ success: true, data: emp, message: 'Employee added successfully' });
  } catch (err) {
    if (err.message.includes('UNIQUE')) return res.status(400).json({ success: false, message: 'Email or employee code already exists' });
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// PUT /api/employees/:id
router.put('/:id', authMiddleware, (req, res) => {
  try {
    const { name, email, phone, department, designation } = req.body;
    const db = getDb();
    db.prepare(
      'UPDATE employees SET name=?, email=?, phone=?, department=?, designation=? WHERE id=?'
    ).run(name, email, phone, department, designation, req.params.id);
    res.json({ success: true, message: 'Employee updated' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// DELETE /api/employees/:id (soft delete)
router.delete('/:id', authMiddleware, (req, res) => {
  try {
    const db = getDb();
    db.prepare('UPDATE employees SET is_active = 0 WHERE id = ?').run(req.params.id);
    res.json({ success: true, message: 'Employee removed' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

module.exports = router;
