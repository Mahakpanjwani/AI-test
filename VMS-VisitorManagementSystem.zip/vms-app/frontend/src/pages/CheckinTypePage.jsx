import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { visitorsAPI } from '../lib/api'
import { AppBar } from '../components/ui'
import { ArrowRight } from 'lucide-react'

export default function CheckinTypePage() {
  const navigate = useNavigate()
  const [selected, setSelected] = useState(null)

  const { data, isLoading } = useQuery({
    queryKey: ['visitor-types'],
    queryFn: () => visitorsAPI.getTypes(),
    staleTime: Infinity,
  })
  const types = data?.data?.data || []

  const handleContinue = () => {
    if (!selected) return
    navigate('/checkin/form', { state: { visitorType: selected } })
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <AppBar title="Select Visitor Type" subtitle="What brings them here?" />

      <div className="flex-1 px-4 pt-4 pb-32">
        <p className="text-sm text-slate-500 mb-5">Choose the type of visit to continue with the right check-in form.</p>

        {isLoading ? (
          <div className="grid grid-cols-2 gap-3">
            {[1,2,3,4,5,6].map(i => (
              <div key={i} className="bg-white rounded-2xl h-28 animate-pulse border border-slate-100" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {types.map(type => (
              <button
                key={type.id}
                onClick={() => setSelected(type)}
                className={`relative bg-white rounded-2xl p-5 text-left border-2 transition-all active:scale-95 ${
                  selected?.id === type.id
                    ? 'border-blue-500 shadow-lg shadow-blue-100'
                    : 'border-slate-100 shadow-sm'
                }`}
              >
                {selected?.id === type.id && (
                  <div className="absolute top-3 right-3 w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center">
                    <svg width="10" height="8" viewBox="0 0 10 8" fill="none">
                      <path d="M1 4L3.5 6.5L9 1" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </div>
                )}
                <div className="text-3xl mb-3">{type.icon}</div>
                <div className="text-sm font-bold text-slate-800">{type.name}</div>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Sticky bottom CTA */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white border-t border-slate-100 shadow-xl" style={{ maxWidth: 430, margin: '0 auto' }}>
        {selected && (
          <div className="flex items-center gap-3 bg-blue-50 border border-blue-100 rounded-xl px-4 py-2.5 mb-3">
            <span className="text-xl">{selected.icon}</span>
            <div>
              <p className="text-xs text-blue-500 font-medium">Selected</p>
              <p className="text-sm font-bold text-blue-700">{selected.name}</p>
            </div>
          </div>
        )}
        <button
          onClick={handleContinue}
          disabled={!selected}
          className="btn-primary"
        >
          Continue <ArrowRight size={18} />
        </button>
      </div>
    </div>
  )
}
