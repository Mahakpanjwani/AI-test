import { Routes, Route, Navigate } from 'react-router-dom'
import { useAuth } from './context/AuthContext'
import LoginPage from './pages/LoginPage'
import HomePage from './pages/HomePage'
import CheckinTypePage from './pages/CheckinTypePage'
import CheckinFormPage from './pages/CheckinFormPage'
import CheckinSuccessPage from './pages/CheckinSuccessPage'
import CheckoutPage from './pages/CheckoutPage'
import DashboardPage from './pages/DashboardPage'
import VisitorLogPage from './pages/VisitorLogPage'
import EmployeesPage from './pages/EmployeesPage'
import LoadingScreen from './components/ui/LoadingScreen'

function PrivateRoute({ children }) {
  const { isAuthenticated, loading } = useAuth()
  if (loading) return <LoadingScreen />
  return isAuthenticated ? children : <Navigate to="/login" replace />
}

function PublicRoute({ children }) {
  const { isAuthenticated, loading } = useAuth()
  if (loading) return <LoadingScreen />
  return isAuthenticated ? <Navigate to="/" replace /> : children
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<PublicRoute><LoginPage /></PublicRoute>} />
      <Route path="/" element={<PrivateRoute><HomePage /></PrivateRoute>} />
      <Route path="/checkin" element={<PrivateRoute><CheckinTypePage /></PrivateRoute>} />
      <Route path="/checkin/form" element={<PrivateRoute><CheckinFormPage /></PrivateRoute>} />
      <Route path="/checkin/success" element={<PrivateRoute><CheckinSuccessPage /></PrivateRoute>} />
      <Route path="/checkout" element={<PrivateRoute><CheckoutPage /></PrivateRoute>} />
      <Route path="/dashboard" element={<PrivateRoute><DashboardPage /></PrivateRoute>} />
      <Route path="/visitors" element={<PrivateRoute><VisitorLogPage /></PrivateRoute>} />
      <Route path="/employees" element={<PrivateRoute><EmployeesPage /></PrivateRoute>} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
