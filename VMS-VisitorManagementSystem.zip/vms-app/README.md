# 🏢 Visitor Management System (VMS)

A full-stack mobile-first Receptionist/Visitor Management application built with React + Node.js + SQLite.

---

## 📁 Project Structure

```
vms-app/
├── backend/          # Node.js + Express + SQLite API
│   ├── routes/       # Auth, Visitors, Employees
│   ├── middleware/   # JWT Auth
│   ├── utils/        # Email (Nodemailer), QR Code
│   ├── database.js   # SQLite schema + seed data
│   └── server.js     # Main server + Cron jobs
│
└── frontend/         # React + Vite + Tailwind CSS
    └── src/
        ├── pages/    # Login, Home, CheckIn, CheckOut, Dashboard, etc.
        ├── components/
        ├── context/  # Auth context
        └── lib/      # Axios API client
```

---

## 🚀 Quick Start

### Prerequisites
- Node.js 18+
- npm or yarn

---

### 1. Backend Setup

```bash
cd backend

# Install dependencies
npm install

# Copy and configure environment
cp .env.example .env
# Edit .env with your SMTP credentials (see Email Setup below)

# Start the server
npm start
# OR for development with auto-reload:
npm run dev
```

Backend runs at: **http://localhost:5000**

---

### 2. Frontend Setup

```bash
cd frontend

# Install dependencies
npm install

# Start development server
npm run dev
```

Frontend runs at: **http://localhost:3000**

---

### 3. Default Login Credentials

| Field | Value |
|-------|-------|
| Receptionist ID | `REC001` |
| Password | `admin123` |

---

## 📧 Email Setup (SMTP)

Edit `backend/.env`:

```env
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=your_email@gmail.com
SMTP_PASS=your_app_password

COMPANY_NAME=Your Company Name
EMAIL_FROM_NAME=Visitor Management System
EMAIL_FROM=noreply@yourcompany.com
```

### Gmail Setup:
1. Go to Google Account → Security → 2-Step Verification → App Passwords
2. Generate an App Password for "Mail"
3. Use that 16-char password as `SMTP_PASS`

> **Note:** If SMTP is not configured, check-ins still work — emails are just skipped silently.

---

## 🔑 Features

### ✅ Check-In Flow
1. Select visitor type (General, Interview, Vendor, Client, Delivery, Government, etc.)
2. Fill visitor details (name, phone, email, company)
3. Select person to meet (searchable employee list)
4. Upload ID proof (Aadhar, PAN, Passport, etc.)
5. Auto check-in time recorded
6. **Auto email to visitor** with digital ID card + QR code
7. **Auto email to host** that visitor has arrived

### 🚪 Check-Out Flow
- See all currently checked-in visitors
- Overdue visitors (>4 hours) highlighted in red
- One-tap checkout with confirmation
- Duration automatically calculated

### ⚠️ Mandatory Checkout Enforcement
- Visitors inside >4 hours are flagged as **Overdue**
- **Automated email reminders** sent every 30 minutes (max 3 reminders)
- **Auto checkout at midnight** for previous day's unchecked visitors
- Dashboard shows compliance percentage
- Reception sees overdue alert on home screen

### 📊 Dashboard
- Today's stats (total, inside, checked-out, overdue)
- Checkout compliance percentage
- Visitor type breakdown (bar chart)
- Check-ins by hour
- Last 7 days trend
- Top visited employees

### 👥 Employee Management
- Add/remove employees
- Searchable list
- Employees receive notification emails when their visitors arrive

---

## 🗄️ Database

Uses **SQLite** (file-based, no installation needed).

Database file: `backend/database.sqlite` (auto-created on first run)

### Tables:
- `receptionists` — Login accounts
- `employees` — People who can be visited
- `visitor_types` — Types of visits
- `visitors` — Main visit records
- `email_logs` — Email send history
- `checkout_reminders` — Reminder tracking

---

## 🏗️ Production Deployment

### Backend (e.g., Railway, Render, VPS):
```bash
cd backend
npm install
npm start
```

### Frontend (e.g., Vercel, Netlify):
```bash
cd frontend
npm run build
# Deploy the 'dist' folder
```

Update `frontend/vite.config.js` proxy target to your production backend URL.

---

## 🔒 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/login` | Login |
| GET  | `/api/auth/me` | Get current user |
| GET  | `/api/visitors/today` | Today's visitors |
| GET  | `/api/visitors/active` | Currently checked in |
| GET  | `/api/visitors/stats` | Dashboard stats |
| POST | `/api/visitors/checkin` | Check in visitor |
| PUT  | `/api/visitors/:id/checkout` | Check out visitor |
| GET  | `/api/employees` | List employees |
| POST | `/api/employees` | Add employee |
| DELETE | `/api/employees/:id` | Remove employee |

---

## 📱 Mobile App (PWA)

The frontend is fully mobile-optimized. To install as a mobile app:
- Open in Chrome on Android → Menu → "Add to Home Screen"
- Open in Safari on iOS → Share → "Add to Home Screen"

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, Vite, Tailwind CSS |
| State | TanStack Query (React Query) |
| Routing | React Router v6 |
| Charts | Recharts |
| Backend | Node.js, Express |
| Database | SQLite (better-sqlite3) |
| Auth | JWT (jsonwebtoken) |
| Email | Nodemailer |
| QR Code | qrcode |
| Scheduler | node-cron |
| File Upload | Multer |
