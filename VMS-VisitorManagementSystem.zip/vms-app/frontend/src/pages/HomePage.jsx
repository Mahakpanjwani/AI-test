import { useNavigate } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { useAuth } from '../context/AuthContext'
import { visitorsAPI } from '../lib/api'
import { StatCard, StatusBadge, Avatar, formatTime, isOverdue, elapsed } from '../components/ui'
import { Bell, LogOut, ChevronRight, Users, BarChart2, ClipboardList, AlertTriangle } from 'lucide-react'

export default function HomePage() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()

  const { data: statsData } = useQuery({
    queryKey: ['stats'],
    queryFn: () => visitorsAPI.getStats(),
    refetchInterval: 60_000,
  })

  const { data: todayData } = useQuery({
    queryKey: ['today-visitors'],
    queryFn: () => visitorsAPI.getToday({ limit: 6 }),
    refetchInterval: 30_000,
  })

  const stats = statsData?.data?.data?.today || {}
  const visitors = todayData?.data?.data || []
  const overdue = visitors.filter(v => v.status === 'checked_in' && isOverdue(v.checkin_time))

  const hour = new Date().getHours()
  const greeting = hour < 12 ? 'Good Morning' : hour < 17 ? 'Good Afternoon' : 'Good Evening'

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <div style={{ background: 'linear-gradient(135deg, #1a56db, #1d4ed8)' }} className="px-5 pt-12 pb-8 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(circle at 80% 20%, white 0%, transparent 50%)' }} />
        <div className="relative flex items-start justify-between">
          <div>
            <p className="text-blue-200 text-sm font-medium">{greeting}! 👋</p>
            <h1 className="text-white text-xl font-extrabold mt-0.5">{user?.name}</h1>
            <p className="text-blue-200 text-xs mt-1">{new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' })}</p>
          </div>
          <button onClick={logout} className="flex items-center gap-1.5 bg-white/15 border border-white/20 text-white text-xs font-semibold px-3 py-2 rounded-xl active:scale-95 transition-transform">
            <LogOut size={14} /> Logout
          </button>
        </div>

        {/* Quick stats in header */}
        <div className="grid grid-cols-3 gap-3 mt-6">
          {[
            { label: 'Today', value: stats.total ?? 0, color: 'white' },
            { label: 'Inside', value: stats.active ?? 0, color: '#86efac' },
            { label: 'Overdue', value: stats.overdue ?? 0, color: '#fca5a5' },
          ].map(s => (
            <div key={s.label} className="bg-white/10 border border-white/20 rounded-2xl p-3 text-center">
              <div className="text-2xl font-extrabold" style={{ color: s.color }}>{s.value}</div>
              <div className="text-xs text-blue-200 font-medium mt-0.5">{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Overdue alert */}
      {overdue.length > 0 && (
        <div className="mx-4 mt-4 bg-amber-50 border border-amber-200 rounded-2xl p-4 flex gap-3">
          <div className="w-9 h-9 bg-amber-100 rounded-xl flex items-center justify-center flex-shrink-0">
            <AlertTriangle size={18} className="text-amber-600" />
          </div>
          <div>
            <p className="text-sm font-bold text-amber-800">{overdue.length} visitor{overdue.length > 1 ? 's' : ''} overdue for checkout</p>
            <p className="text-xs text-amber-600 mt-0.5">They have been inside for over 4 hours</p>
            <button onClick={() => navigate('/checkout')} className="text-xs font-bold text-amber-700 mt-1.5 underline underline-offset-2">
              View & Check Out →
            </button>
          </div>
        </div>
      )}

      {/* Main Actions */}
      <div className="px-4 mt-5">
        <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Quick Actions</p>
        <div className="grid grid-cols-2 gap-3">
          <button onClick={() => navigate('/checkin')}
            className="bg-blue-600 rounded-2xl p-5 text-left active:scale-95 transition-transform shadow-lg shadow-blue-200">
            <div className="text-2xl mb-3">✅</div>
            <div className="text-white font-bold text-base">Check In</div>
            <div className="text-blue-200 text-xs mt-0.5">Register visitor</div>
          </button>
          <button onClick={() => navigate('/checkout')}
            className="bg-white border border-slate-200 rounded-2xl p-5 text-left active:scale-95 transition-transform shadow-sm">
            <div className="text-2xl mb-3">🚪</div>
            <div className="text-slate-900 font-bold text-base">Check Out</div>
            <div className="text-slate-400 text-xs mt-0.5">{stats.active ?? 0} inside</div>
          </button>
        </div>
      </div>

      {/* Navigation Pills */}
      <div className="px-4 mt-4">
        <div className="grid grid-cols-3 gap-2">
          {[
            { icon: <BarChart2 size={18} />, label: 'Dashboard', path: '/dashboard', color: 'bg-purple-50 text-purple-600' },
            { icon: <ClipboardList size={18} />, label: 'Visitor Log', path: '/visitors', color: 'bg-emerald-50 text-emerald-600' },
            { icon: <Users size={18} />, label: 'Employees', path: '/employees', color: 'bg-orange-50 text-orange-600' },
          ].map(item => (
            <button key={item.path} onClick={() => navigate(item.path)}
              className="bg-white border border-slate-100 rounded-2xl p-3 text-center active:scale-95 transition-transform">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center mx-auto mb-2 ${item.color}`}>
                {item.icon}
              </div>
              <span className="text-xs font-semibold text-slate-700">{item.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Recent visitors */}
      <div className="px-4 mt-5 pb-8">
        <div className="flex items-center justify-between mb-3">
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Recent Visitors</p>
          <button onClick={() => navigate('/visitors')} className="text-xs font-semibold text-blue-600">See All</button>
        </div>

        {visitors.length === 0 ? (
          <div className="bg-white rounded-2xl border border-slate-100 py-10 text-center">
            <div className="text-4xl mb-2">📋</div>
            <p className="text-sm text-slate-400">No visitors today</p>
          </div>
        ) : (
          <div className="space-y-2">
            {visitors.map(v => (
              <div key={v.id} className={`visitor-card ${v.status === 'checked_in' && isOverdue(v.checkin_time) ? 'overdue-card' : ''}`}
                onClick={() => v.status === 'checked_in' ? navigate('/checkout') : null}>
                <div className="flex items-center gap-3">
                  <Avatar name={v.name} size="md" />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <p className="font-bold text-slate-900 text-sm truncate">{v.name}</p>
                      <StatusBadge status={v.status} overdue={v.status === 'checked_in' && isOverdue(v.checkin_time)} />
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5 truncate">
                      {v.visitor_type_icon} {v.visitor_type_name} · Meets {v.person_to_meet_name}
                    </p>
                    <p className="text-xs text-slate-400 mt-0.5">
                      In: {formatTime(v.checkin_time)}
                      {v.checkout_time ? ` · Out: ${formatTime(v.checkout_time)}` : ` (${elapsed(v.checkin_time)})`}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
