require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const cron = require('node-cron');
const { initDb, getDb } = require('./database');
const { sendCheckoutReminderEmail } = require('./utils/email');

const app = express();
const PORT = process.env.PORT || 5000;

// Initialize DB
initDb();

// Middleware
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:3000',
  credentials: true,
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Static uploads
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/visitors', require('./routes/visitors'));
app.use('/api/employees', require('./routes/employees'));

// Health check
app.get('/api/health', (req, res) => {
  res.json({ success: true, message: 'VMS API running', timestamp: new Date().toISOString() });
});

// 404 handler
app.use('/api/*', (req, res) => {
  res.status(404).json({ success: false, message: 'API route not found' });
});

// ─────────────────────────────────────────────
// CRON JOBS — Enforce checkout compliance
// ─────────────────────────────────────────────

// Every 30 minutes: check for visitors who've been in > 4 hours without checkout
cron.schedule('*/30 * * * *', async () => {
  console.log('⏰ Running checkout compliance check...');
  const db = getDb();
  const fourHoursAgo = new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString();

  const overdueVisitors = db.prepare(`
    SELECT v.*, e.name AS person_to_meet_name, e.email AS person_to_meet_email, vt.name AS visitor_type_name
    FROM visitors v
    LEFT JOIN employees e ON v.person_to_meet_id = e.id
    LEFT JOIN visitor_types vt ON v.visitor_type_id = vt.id
    WHERE v.status = 'checked_in' AND v.checkin_time < ?
  `).all(fourHoursAgo);

  for (const visitor of overdueVisitors) {
    // Check how many reminders sent
    const reminders = db.prepare('SELECT COUNT(*) as cnt FROM checkout_reminders WHERE visitor_id = ?').get(visitor.id);
    if (reminders.cnt < 3) { // Max 3 reminders
      await sendCheckoutReminderEmail(visitor);
      const existing = db.prepare('SELECT id FROM checkout_reminders WHERE visitor_id = ?').get(visitor.id);
      if (existing) {
        db.prepare('UPDATE checkout_reminders SET reminder_count = reminder_count + 1, reminded_at = CURRENT_TIMESTAMP WHERE visitor_id = ?').run(visitor.id);
      } else {
        db.prepare('INSERT INTO checkout_reminders (visitor_id) VALUES (?)').run(visitor.id);
      }
      console.log(`📧 Checkout reminder sent for visitor: ${visitor.name} (${visitor.visitor_id})`);
    }
  }

  if (overdueVisitors.length > 0) {
    console.log(`⚠️ ${overdueVisitors.length} overdue visitor(s) found`);
  }
});

// Daily midnight: auto-checkout any visitors still marked as checked_in from previous days
cron.schedule('0 0 * * *', () => {
  console.log('🌙 Running midnight auto-checkout...');
  const db = getDb();
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  const yesterdayStr = yesterday.toISOString().split('T')[0];

  const result = db.prepare(`
    UPDATE visitors
    SET status = 'checked_out', checkout_time = DATE(checkin_time, '+1 day', 'start of day', '-1 second'), notes = COALESCE(notes || ' ', '') || '[Auto checkout at midnight]'
    WHERE status = 'checked_in' AND DATE(checkin_time) <= ?
  `).run(yesterdayStr);

  console.log(`🌙 Auto-checked out ${result.changes} visitor(s) from previous day`);
});

// Error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ success: false, message: err.message || 'Internal server error' });
});

app.listen(PORT, () => {
  console.log(`🚀 VMS Backend running on http://localhost:${PORT}`);
  console.log(`📡 API available at http://localhost:${PORT}/api`);
  console.log(`🔐 Default login: REC001 / admin123`);
});
