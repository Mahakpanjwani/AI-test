import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { visitorsAPI } from '../lib/api'
import { AppBar, Avatar, StatusBadge, ConfirmModal, formatTime, isOverdue, elapsed } from '../components/ui'
import { Search, Clock, AlertTriangle, CheckCircle } from 'lucide-react'
import toast from 'react-hot-toast'

export default function CheckoutPage() {
  const qc = useQueryClient()
  const [search, setSearch] = useState('')
  const [confirmVisitor, setConfirmVisitor] = useState(null)
  const [doneVisitor, setDoneVisitor] = useState(null)

  const { data, isLoading, refetch } = useQuery({
    queryKey: ['active-visitors'],
    queryFn: () => visitorsAPI.getActive(),
    refetchInterval: 30_000,
  })

  const visitors = (data?.data?.data || []).filter(v =>
    !search || v.name.toLowerCase().includes(search.toLowerCase()) ||
    v.visitor_id.toLowerCase().includes(search.toLowerCase()) ||
    v.phone?.includes(search)
  )

  const checkoutMutation = useMutation({
    mutationFn: (id) => visitorsAPI.checkout(id),
    onSuccess: (res) => {
      const v = res.data.data
      setConfirmVisitor(null)
      setDoneVisitor(v)
      qc.invalidateQueries(['active-visitors'])
      qc.invalidateQueries(['today-visitors'])
      qc.invalidateQueries(['stats'])
    },
    onError: (err) => {
      toast.error(err.response?.data?.message || 'Checkout failed')
    }
  })

  const overdue = visitors.filter(v => isOverdue(v.checkin_time))

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <AppBar
        title="Check Out"
        subtitle={`${visitors.length} visitor${visitors.length !== 1 ? 's' : ''} inside`}
      />

      <div className="px-4 pt-4 pb-2 bg-white border-b border-slate-100">
        <div className="relative">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            className="input-field pl-9"
            placeholder="Search by name, ID or phone..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>
      </div>

      <div className="flex-1 px-4 py-4 pb-8 space-y-3">

        {/* Overdue alert */}
        {overdue.length > 0 && !search && (
          <div className="bg-red-50 border border-red-200 rounded-2xl p-4">
            <div className="flex gap-2 items-center mb-2">
              <AlertTriangle size={16} className="text-red-500" />
              <p className="text-sm font-bold text-red-700">{overdue.length} visitor{overdue.length > 1 ? 's' : ''} overdue for checkout</p>
            </div>
            <p className="text-xs text-red-500">Inside for more than 4 hours — please follow up immediately</p>
          </div>
        )}

        {isLoading ? (
          [1,2,3].map(i => (
            <div key={i} className="bg-white rounded-2xl h-24 animate-pulse border border-slate-100" />
          ))
        ) : visitors.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mb-4">
              <CheckCircle size={28} className="text-emerald-500" />
            </div>
            <h3 className="text-base font-bold text-slate-700 mb-1">All Clear!</h3>
            <p className="text-sm text-slate-400">No visitors currently inside</p>
          </div>
        ) : (
          visitors.map(v => {
            const overdue = isOverdue(v.checkin_time)
            return (
              <div key={v.id}
                onClick={() => setConfirmVisitor(v)}
                className={`bg-white rounded-2xl border p-4 cursor-pointer active:scale-98 transition-transform ${overdue ? 'border-red-200' : 'border-slate-100'}`}>
                <div className="flex items-start gap-3">
                  <Avatar name={v.name} size="md" color={overdue ? 'amber' : 'blue'} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <div>
                        <p className="font-bold text-slate-900 text-sm">{v.name}</p>
                        <p className="text-xs text-slate-400">{v.visitor_id}</p>
                      </div>
                      <StatusBadge status="checked_in" overdue={overdue} />
                    </div>

                    <div className="flex items-center gap-3 mt-2">
                      <div className="flex items-center gap-1 text-xs text-slate-500">
                        <Clock size={12} />
                        <span>In: {formatTime(v.checkin_time)}</span>
                      </div>
                      <span className="text-xs text-slate-300">·</span>
                      <span className="text-xs text-slate-500">{elapsed(v.checkin_time)}</span>
                    </div>

                    <div className="flex flex-wrap gap-2 mt-2">
                      <span className="badge badge-blue">{v.visitor_type_icon} {v.visitor_type_name}</span>
                      <span className="text-xs text-slate-400">Meets: {v.person_to_meet_name}</span>
                    </div>

                    {overdue && (
                      <div className="flex items-center gap-1.5 mt-2 bg-red-50 rounded-lg px-2 py-1.5">
                        <AlertTriangle size={12} className="text-red-500" />
                        <span className="text-xs font-semibold text-red-600">Checkout overdue — tap to check out</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="mt-3 pt-3 border-t border-slate-50">
                  <button
                    onClick={(e) => { e.stopPropagation(); setConfirmVisitor(v) }}
                    className="w-full bg-blue-50 text-blue-700 font-semibold text-sm py-2 rounded-xl active:bg-blue-100 transition-colors">
                    Check Out →
                  </button>
                </div>
              </div>
            )
          })
        )}
      </div>

      {/* Confirm Checkout Modal */}
      <ConfirmModal
        open={!!confirmVisitor}
        onClose={() => setConfirmVisitor(null)}
        onConfirm={() => checkoutMutation.mutate(confirmVisitor.id)}
        title="Confirm Check-Out"
        description={`Check out ${confirmVisitor?.name}? This will record their departure and complete the visit.`}
        confirmText="Check Out"
        confirmClass="btn-success"
        loading={checkoutMutation.isPending}
      >
        {confirmVisitor && (
          <div className="bg-slate-50 rounded-xl p-3 mb-4 text-left">
            <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs">
              <div><span className="text-slate-400">ID:</span> <span className="font-semibold">{confirmVisitor.visitor_id}</span></div>
              <div><span className="text-slate-400">In:</span> <span className="font-semibold">{formatTime(confirmVisitor.checkin_time)}</span></div>
              <div><span className="text-slate-400">Duration:</span> <span className="font-semibold">{elapsed(confirmVisitor.checkin_time)}</span></div>
              <div><span className="text-slate-400">Meets:</span> <span className="font-semibold">{confirmVisitor.person_to_meet_name}</span></div>
            </div>
          </div>
        )}
      </ConfirmModal>

      {/* Success Modal */}
      {doneVisitor && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-6 bg-black/50 animate-fade-in" style={{ maxWidth: 430, margin: '0 auto' }}>
          <div className="bg-white rounded-2xl p-6 w-full animate-scale-in text-center">
            <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle size={32} className="text-emerald-500" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-1">Checked Out!</h3>
            <p className="text-sm text-slate-500 mb-1">
              <strong>{doneVisitor.name}</strong> has successfully checked out
            </p>
            <p className="text-sm text-slate-400 mb-5">
              Duration: <strong>{doneVisitor.duration_minutes}m</strong>
            </p>
            <button onClick={() => setDoneVisitor(null)} className="btn-primary">
              Done
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
