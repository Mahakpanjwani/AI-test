import { useState } from 'react'
import { useAuth } from '../context/AuthContext'
import { useNavigate } from 'react-router-dom'
import toast from 'react-hot-toast'
import { Eye, EyeOff, LogIn } from 'lucide-react'

export default function LoginPage() {
  const { login } = useAuth()
  const navigate = useNavigate()
  const [form, setForm] = useState({ employee_id: '', password: '' })
  const [showPw, setShowPw] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!form.employee_id || !form.password) {
      setError('Please enter your ID and password')
      return
    }
    setLoading(true)
    setError('')
    try {
      await login(form.employee_id.toUpperCase(), form.password)
      toast.success('Welcome back!')
      navigate('/', { replace: true })
    } catch (err) {
      const msg = err.response?.data?.message || 'Invalid credentials'
      setError(msg)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex flex-col" style={{ background: 'linear-gradient(160deg, #1a56db 0%, #1e40af 60%, #1d4ed8 100%)' }}>
      {/* Top decoration */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 pt-16 pb-8">
        {/* Logo */}
        <div className="mb-8 text-center animate-slide-up">
          <div className="w-20 h-20 bg-white/15 border-2 border-white/30 rounded-3xl flex items-center justify-center text-4xl mx-auto mb-5 backdrop-blur-sm">
            🏢
          </div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight">Visitor Management</h1>
          <p className="text-blue-200 text-sm mt-1">Receptionist Portal</p>
        </div>

        {/* Card */}
        <div className="w-full bg-white rounded-3xl p-6 shadow-2xl animate-slide-up" style={{ animationDelay: '0.1s' }}>
          <h2 className="text-lg font-bold text-slate-900 mb-1">Sign In</h2>
          <p className="text-sm text-slate-400 mb-6">Enter your credentials to continue</p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1.5">Receptionist ID</label>
              <input
                className="input-field"
                placeholder="e.g. REC001"
                value={form.employee_id}
                onChange={e => setForm(f => ({ ...f, employee_id: e.target.value.toUpperCase() }))}
                autoCapitalize="characters"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1.5">Password</label>
              <div className="relative">
                <input
                  className="input-field pr-12"
                  type={showPw ? 'text' : 'password'}
                  placeholder="Enter password"
                  value={form.password}
                  onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
                />
                <button type="button" onClick={() => setShowPw(p => !p)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 p-1">
                  {showPw ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-100 rounded-xl px-4 py-3">
                <p className="text-sm text-red-600 font-medium">{error}</p>
              </div>
            )}

            <button type="submit" disabled={loading} className="btn-primary">
              {loading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <><LogIn size={18} /> Sign In</>
              )}
            </button>
          </form>

          <div className="mt-5 p-3 bg-slate-50 rounded-xl">
            <p className="text-xs text-slate-400 text-center">
              Demo: <span className="font-mono font-semibold text-slate-600">REC001</span> / <span className="font-mono font-semibold text-slate-600">admin123</span>
            </p>
          </div>
        </div>
      </div>

      <p className="text-blue-300/60 text-xs text-center pb-8">
        © {new Date().getFullYear()} Visitor Management System
      </p>
    </div>
  )
}
