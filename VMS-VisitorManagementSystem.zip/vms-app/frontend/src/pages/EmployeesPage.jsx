import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { employeesAPI } from '../lib/api'
import { AppBar, Avatar, BottomSheet, FormField } from '../components/ui'
import { Search, Plus, Trash2 } from 'lucide-react'
import toast from 'react-hot-toast'

export default function EmployeesPage() {
  const qc = useQueryClient()
  const [search, setSearch] = useState('')
  const [showAdd, setShowAdd] = useState(false)
  const [form, setForm] = useState({ name:'', email:'', phone:'', department:'', designation:'', employee_code:'' })

  const { data, isLoading } = useQuery({
    queryKey: ['employees', search],
    queryFn: () => employeesAPI.getAll({ search }),
  })
  const employees = data?.data?.data || []

  const addMutation = useMutation({
    mutationFn: (d) => employeesAPI.create(d),
    onSuccess: () => { toast.success('Employee added'); setShowAdd(false); setForm({ name:'',email:'',phone:'',department:'',designation:'',employee_code:'' }); qc.invalidateQueries(['employees']) },
    onError: (e) => toast.error(e.response?.data?.message || 'Error adding employee'),
  })

  const deleteMutation = useMutation({
    mutationFn: (id) => employeesAPI.delete(id),
    onSuccess: () => { toast.success('Employee removed'); qc.invalidateQueries(['employees']) },
  })

  const DEPT_COLORS = { Engineering:'blue', 'Human Resources':'purple', Sales:'green', Finance:'amber', Marketing:'red', Operations:'blue', Legal:'purple', IT:'green', Administration:'amber', Management:'red' }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <AppBar title="Employees" subtitle={`${employees.length} active`}
        right={
          <button onClick={() => setShowAdd(true)} className="flex items-center gap-1.5 bg-blue-600 text-white text-xs font-bold px-3 py-2 rounded-xl">
            <Plus size={14} /> Add
          </button>
        }
      />

      <div className="px-4 py-3 bg-white border-b border-slate-100">
        <div className="relative">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input className="input-field pl-9" placeholder="Search employees..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
      </div>

      <div className="flex-1 px-4 py-4 pb-8 space-y-2">
        {isLoading ? [1,2,3,4,5].map(i => <div key={i} className="bg-white rounded-2xl h-16 animate-pulse border border-slate-100" />) :
        employees.map(emp => (
          <div key={emp.id} className="bg-white rounded-2xl border border-slate-100 p-4 flex items-center gap-3">
            <Avatar name={emp.name} size="md" color={Object.keys(DEPT_COLORS).includes(emp.department) ? DEPT_COLORS[emp.department] : 'blue'} />
            <div className="flex-1 min-w-0">
              <p className="font-bold text-slate-900 text-sm">{emp.name}</p>
              <p className="text-xs text-slate-400">{emp.designation} · {emp.department}</p>
              <p className="text-xs text-slate-400">{emp.employee_code} · {emp.email}</p>
            </div>
            <button onClick={() => { if(window.confirm(`Remove ${emp.name}?`)) deleteMutation.mutate(emp.id) }}
              className="w-8 h-8 flex items-center justify-center text-slate-300 hover:text-red-400 transition-colors">
              <Trash2 size={16} />
            </button>
          </div>
        ))}
      </div>

      <BottomSheet open={showAdd} onClose={() => setShowAdd(false)} title="Add Employee">
        <div className="pt-2 space-y-0">
          <FormField label="Full Name" required><input className="input-field" placeholder="Employee name" value={form.name} onChange={e => setForm(f=>({...f,name:e.target.value}))} /></FormField>
          <FormField label="Email" required><input className="input-field" type="email" placeholder="email@company.com" value={form.email} onChange={e => setForm(f=>({...f,email:e.target.value}))} /></FormField>
          <FormField label="Phone"><input className="input-field" placeholder="+91 XXXXX XXXXX" value={form.phone} onChange={e => setForm(f=>({...f,phone:e.target.value}))} /></FormField>
          <div className="grid grid-cols-2 gap-3">
            <FormField label="Department" required><input className="input-field" placeholder="e.g. IT" value={form.department} onChange={e => setForm(f=>({...f,department:e.target.value}))} /></FormField>
            <FormField label="Designation"><input className="input-field" placeholder="e.g. Manager" value={form.designation} onChange={e => setForm(f=>({...f,designation:e.target.value}))} /></FormField>
          </div>
          <FormField label="Employee Code"><input className="input-field" placeholder="EMP001" value={form.employee_code} onChange={e => setForm(f=>({...f,employee_code:e.target.value}))} /></FormField>
          <div className="pt-2">
            <button onClick={() => addMutation.mutate(form)} disabled={addMutation.isPending} className="btn-primary">
              {addMutation.isPending ? 'Adding...' : 'Add Employee'}
            </button>
          </div>
        </div>
      </BottomSheet>
    </div>
  )
}
