const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const path = require('path');
require('dotenv').config();

const DB_PATH = process.env.DB_PATH || './database.sqlite';

let db;

function getDb() {
  if (!db) {
    db = new Database(DB_PATH);
    db.pragma('journal_mode = WAL');
    db.pragma('foreign_keys = ON');
  }
  return db;
}

function initDb() {
  const db = getDb();

  // Receptionists table
  db.exec(`
    CREATE TABLE IF NOT EXISTS receptionists (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      employee_id TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      role TEXT DEFAULT 'receptionist',
      is_active INTEGER DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Employees table (people who can be visited)
  db.exec(`
    CREATE TABLE IF NOT EXISTS employees (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      phone TEXT,
      department TEXT NOT NULL,
      designation TEXT,
      employee_code TEXT UNIQUE,
      avatar_initials TEXT,
      is_active INTEGER DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Visitor types table
  db.exec(`
    CREATE TABLE IF NOT EXISTS visitor_types (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT UNIQUE NOT NULL,
      icon TEXT,
      color TEXT,
      is_active INTEGER DEFAULT 1
    )
  `);

  // Visitors table
  db.exec(`
    CREATE TABLE IF NOT EXISTS visitors (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      visitor_id TEXT UNIQUE NOT NULL,
      visitor_type_id INTEGER NOT NULL,
      name TEXT NOT NULL,
      phone TEXT NOT NULL,
      email TEXT,
      company TEXT,
      person_to_meet_id INTEGER NOT NULL,
      purpose TEXT,
      id_proof_type TEXT,
      id_proof_file TEXT,
      id_proof_number TEXT,
      checkin_time DATETIME DEFAULT CURRENT_TIMESTAMP,
      checkout_time DATETIME,
      expected_checkout DATETIME,
      checkin_by INTEGER,
      checkout_by INTEGER,
      digital_id_card TEXT,
      qr_code TEXT,
      email_sent_visitor INTEGER DEFAULT 0,
      email_sent_host INTEGER DEFAULT 0,
      notes TEXT,
      status TEXT DEFAULT 'checked_in',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (visitor_type_id) REFERENCES visitor_types(id),
      FOREIGN KEY (person_to_meet_id) REFERENCES employees(id),
      FOREIGN KEY (checkin_by) REFERENCES receptionists(id),
      FOREIGN KEY (checkout_by) REFERENCES receptionists(id)
    )
  `);

  // Email logs
  db.exec(`
    CREATE TABLE IF NOT EXISTS email_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      visitor_id INTEGER,
      recipient_email TEXT NOT NULL,
      recipient_type TEXT,
      subject TEXT,
      status TEXT DEFAULT 'pending',
      sent_at DATETIME,
      error_message TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (visitor_id) REFERENCES visitors(id)
    )
  `);

  // Checkout reminders log
  db.exec(`
    CREATE TABLE IF NOT EXISTS checkout_reminders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      visitor_id INTEGER NOT NULL,
      reminded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      reminder_count INTEGER DEFAULT 1,
      FOREIGN KEY (visitor_id) REFERENCES visitors(id)
    )
  `);

  // Seed default data
  seedDefaultData(db);

  console.log('✅ Database initialized successfully');
  return db;
}

function seedDefaultData(db) {
  // Seed receptionist admin
  const existingAdmin = db.prepare('SELECT id FROM receptionists WHERE employee_id = ?').get('REC001');
  if (!existingAdmin) {
    const hashedPw = bcrypt.hashSync('admin123', 10);
    db.prepare(`
      INSERT INTO receptionists (employee_id, name, email, password, role)
      VALUES (?, ?, ?, ?, ?)
    `).run('REC001', 'Front Desk Admin', 'admin@company.com', hashedPw, 'admin');
    console.log('✅ Default receptionist created: REC001 / admin123');
  }

  // Seed visitor types
  const types = [
    { name: 'General Visitor', icon: '👤', color: '#1a56db' },
    { name: 'For Interview',   icon: '💼', color: '#059669' },
    { name: 'Vendor/Supplier', icon: '📦', color: '#d97706' },
    { name: 'Client',          icon: '🤝', color: '#7c3aed' },
    { name: 'Delivery',        icon: '🚚', color: '#0891b2' },
    { name: 'Government',      icon: '🏛️', color: '#dc2626' },
    { name: 'Contractor',      icon: '🔧', color: '#374151' },
    { name: 'Personal',        icon: '👥', color: '#be185d' },
  ];
  const typeInsert = db.prepare('INSERT OR IGNORE INTO visitor_types (name, icon, color) VALUES (?, ?, ?)');
  types.forEach(t => typeInsert.run(t.name, t.icon, t.color));

  // Seed employees
  const employees = [
    { name: 'Priya Sharma',    email: 'priya.sharma@company.com',    phone: '9876543210', department: 'Engineering',  designation: 'Senior Engineer',    code: 'EMP001' },
    { name: 'Rahul Mehta',     email: 'rahul.mehta@company.com',     phone: '9876543211', department: 'Human Resources', designation: 'HR Manager',       code: 'EMP002' },
    { name: 'Anita Singh',     email: 'anita.singh@company.com',     phone: '9876543212', department: 'Sales',         designation: 'Sales Head',          code: 'EMP003' },
    { name: 'Deepak Joshi',    email: 'deepak.joshi@company.com',    phone: '9876543213', department: 'Finance',       designation: 'CFO',                 code: 'EMP004' },
    { name: 'Kavita Patel',    email: 'kavita.patel@company.com',    phone: '9876543214', department: 'Marketing',     designation: 'Marketing Lead',      code: 'EMP005' },
    { name: 'Suresh Kumar',    email: 'suresh.kumar@company.com',    phone: '9876543215', department: 'Operations',    designation: 'Ops Manager',         code: 'EMP006' },
    { name: 'Neha Gupta',      email: 'neha.gupta@company.com',      phone: '9876543216', department: 'Legal',         designation: 'Legal Counsel',       code: 'EMP007' },
    { name: 'Amit Verma',      email: 'amit.verma@company.com',      phone: '9876543217', department: 'IT',            designation: 'IT Head',             code: 'EMP008' },
    { name: 'Pooja Saxena',    email: 'pooja.saxena@company.com',    phone: '9876543218', department: 'Administration','designation': 'Admin Manager',     code: 'EMP009' },
    { name: 'Vikram Bhatnagar',email: 'vikram.b@company.com',        phone: '9876543219', department: 'Management',    designation: 'CEO',                 code: 'EMP010' },
  ];
  const empInsert = db.prepare(`
    INSERT OR IGNORE INTO employees (name, email, phone, department, designation, employee_code, avatar_initials)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);
  employees.forEach(e => {
    const initials = e.name.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();
    empInsert.run(e.name, e.email, e.phone, e.department, e.designation, e.code, initials);
  });
}

module.exports = { getDb, initDb };
